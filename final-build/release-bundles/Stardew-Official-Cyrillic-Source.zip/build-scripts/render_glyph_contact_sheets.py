from __future__ import annotations

import json
from math import ceil
from pathlib import Path

from PIL import Image, ImageDraw


CELL_W = 40
CELL_H = 40
GLYPH_Y = 4
LABEL_Y = 28
COLS = 16
BG = (250, 244, 232, 255)
FG = (43, 35, 30, 255)
GRID = (211, 198, 184, 255)


def load_records(metadata_path: Path, glyphs_dir: Path) -> list[dict]:
    data = json.loads(metadata_path.read_text(encoding="utf-8"))
    records: list[dict] = []
    for glyph in data["glyphs"]:
        image_path = glyphs_dir / glyph["image"]
        if not image_path.exists():
            continue
        records.append(
            {
                "char_id": glyph["char_id"],
                "char": glyph.get("char", chr(glyph["char_id"])),
                "image_path": image_path,
            }
        )
    return records


def render_sheet(records: list[dict], output_path: Path, title: str) -> None:
    rows = ceil(len(records) / COLS) + 1
    image = Image.new("RGBA", (COLS * CELL_W, rows * CELL_H), BG)
    draw = ImageDraw.Draw(image)

    draw.rectangle((0, 0, image.width - 1, CELL_H - 1), fill=(229, 217, 203, 255), outline=GRID)
    draw.text((8, 10), title, fill=FG)

    for index, record in enumerate(records):
        row = index // COLS + 1
        col = index % COLS
        x0 = col * CELL_W
        y0 = row * CELL_H
        x1 = x0 + CELL_W - 1
        y1 = y0 + CELL_H - 1
        draw.rectangle((x0, y0, x1, y1), outline=GRID)

        glyph = Image.open(record["image_path"]).convert("RGBA")
        gx = x0 + max(0, (CELL_W - glyph.width) // 2)
        gy = y0 + GLYPH_Y
        image.alpha_composite(glyph, (gx, gy))

        label = f"U+{record['char_id']:04X}"
        draw.text((x0 + 3, y0 + LABEL_Y), label, fill=FG)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    image.save(output_path)


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    preview_root = project_root / "final-build" / "glyph-previews"
    preview_root.mkdir(parents=True, exist_ok=True)

    targets = [
        (
            "regular",
            project_root / "russian-bg-work" / "glyphs_augmented.json",
            project_root / "russian-bg-work" / "glyphs",
            "Regular Glyph Contact Sheet",
        ),
        (
            "bold",
            project_root / "russian-bg-bold-work" / "glyphs_augmented.json",
            project_root / "russian-bg-bold-work" / "glyphs",
            "Bold Glyph Contact Sheet",
        ),
        (
            "italic",
            project_root / "russian-bg-italic-work" / "glyphs_augmented.json",
            project_root / "russian-bg-italic-work" / "glyphs",
            "Italic Glyph Contact Sheet",
        ),
    ]

    outputs = []
    for key, metadata_path, glyphs_dir, title in targets:
        records = load_records(metadata_path, glyphs_dir)
        output_path = preview_root / f"{key}_glyph_contact_sheet.png"
        render_sheet(records, output_path, title)
        outputs.append(str(output_path))

    report = {"outputs": outputs}
    (preview_root / "build-report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
